package gui;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class Client {

	private JFrame frame;
	private JLabel[][] slots;
	private JButton[] buttons;
	private int xsize = 7;
	private int ysize = 6;
	public PrintWriter out;
	public BufferedReader in;
	public Socket s;
	private String nom;

	public Client() {

		try {
			this.s = new Socket("0.tcp.ngrok.io", 11062);
			this.out = new PrintWriter(this.s.getOutputStream(), true);
			this.in = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF8"));
		} catch (IOException e) {
			e.getMessage();
		}

		this.nom = this.getPseudo();
		out.println(this.nom);

		this.frame = new JFrame("Puissance 4");

		JPanel panel = (JPanel) frame.getContentPane();
		panel.setLayout(new GridLayout(xsize, ysize));

		this.slots = new JLabel[xsize][ysize + 1];
		this.buttons = new JButton[xsize];

		for (int column = 0; column < ysize; column++) {
			for (int row = 0; row < xsize; row++) {
				slots[row][column] = new JLabel();
				slots[row][column].setHorizontalAlignment(SwingConstants.CENTER);
				slots[row][column].setBorder(new LineBorder(Color.black));
				panel.add(slots[row][column]);
			}
		}

		for (int i = 0; i < xsize; i++) {
			buttons[i] = new JButton("" + (i + 1));
			buttons[i].setActionCommand("" + i);
			buttons[i].addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int a = Integer.parseInt(e.getActionCommand());
					this.envoieColonneAuServeur(a);
				}

				public void envoieColonneAuServeur(int c) {
					out.println(c);
				}
			});
			panel.add(buttons[i]);
		}

		this.frame.setContentPane(panel);
		this.frame.setSize(700, 600);
		this.frame.setVisible(true);
		this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public JsonObject listServeur() {
		try {
			String test = in.readLine();
			JsonObject res = JsonParser.parseString(test.toString()).getAsJsonObject();
			return res;
		} catch (Exception e) {
			e.printStackTrace();
		}
		JsonObject res = new JsonObject();
		res.addProperty("error", "erreur");
		return res;
	}

	public void updateGame(String plateau) {
		String[] tabo = plateau.split("\\r?\\n");
		for (int ligne = 0; ligne < ysize; ligne++) {
			for (int colonne = 0; colonne < xsize; colonne++) {
				String elementCase = tabo[ligne].split("")[colonne];
				if (elementCase.equals("1")) {
					this.slots[colonne][ligne].setOpaque(true);
					this.slots[colonne][ligne].setBackground(Color.red);
				} else if (elementCase.equals("2")) {
					this.slots[colonne][ligne].setOpaque(true);
					this.slots[colonne][ligne].setBackground(Color.yellow);
				}
			}
		}
	}

	public void disableGame() {
		for (JButton button : this.buttons) {
			button.setEnabled(false);
		}
	}

	public void enableGame() {
		for (JButton button : this.buttons) {
			button.setEnabled(true);
		}
	}

	public String getPseudo() {
		String res = JOptionPane.showInputDialog(null, "Veuillez entrer un pseudo", "Username",
				JOptionPane.QUESTION_MESSAGE);
		if (res != null) {
			if (res.contains("adversaire") || res.contains("attente") || res.contains("gagn�")
					|| res.contains("d�connect�")) {
				return getPseudo();
			}
			return res;
		} else {
			return getPseudo();
		}
	}

	public boolean isEgalit�(String plateau) {
		String[] tabo = plateau.split("\\r?\\n");
		for (int ligne = 0; ligne < ysize; ligne++) {
			for (int colonne = 0; colonne < xsize; colonne++) {
				String elementCase = tabo[ligne].split("")[colonne];
				if (elementCase.equals(" ")) {
					return false;
				}
			}
		}
		return true;
	}

	public static void main(String[] args) {

		Client gui = new Client();
		try {
			while (true) {
				JsonObject json = gui.listServeur();
				String message = json.toString();
				if (message.contains("adversaire")) {
					String waitingMessage = json.get("message").getAsString();
					gui.frame.setTitle("Puissance 4 - " + waitingMessage);
					gui.disableGame();
				} else if (message.contains("gagn�")) {
					String winnerMessage = json.get("message").getAsString();
					String finalPlateau = json.get("plateau").getAsString();
					gui.updateGame(finalPlateau);
					JOptionPane.showMessageDialog(null, winnerMessage, "Partie termin�e !",
							JOptionPane.INFORMATION_MESSAGE);
					gui.disableGame();
					gui.in.close();
					gui.out.close();
					gui.s.close();
					System.exit(0);
					break;
				} else if (message.contains("d�connect�")) {
					String errorMessage = json.get("message").getAsString();
					String finalPlateau = json.get("plateau").getAsString();
					gui.updateGame(finalPlateau);
					JOptionPane.showMessageDialog(null, errorMessage, "Partie termin�e !",
							JOptionPane.INFORMATION_MESSAGE);
					gui.disableGame();
					gui.in.close();
					gui.out.close();
					gui.s.close();
					System.exit(0);
					break;
				} else if (message.contains("attente")) {
					String jsonInfoPlateau = json.get("plateau").getAsString();
					String waitingMessage = json.get("message").getAsString();
					String couleur = json.get("couleur").getAsString();
					gui.updateGame(jsonInfoPlateau);
					gui.frame.setTitle("Puissance 4 - " + couleur + " - " + waitingMessage);
					gui.disableGame();
				} else {
					String jsonInfoPlateau = json.get("plateau").getAsString();
					String couleur = json.get("couleur").getAsString();
					System.out.println(jsonInfoPlateau);
					gui.frame.setTitle("Puissance 4 - " + couleur + " - " + json.get("message").getAsString());
					gui.updateGame(jsonInfoPlateau);
					if (json.get("message").toString().contains("vous de jouer")) {
						gui.enableGame();
						gui.updateGame(jsonInfoPlateau);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
